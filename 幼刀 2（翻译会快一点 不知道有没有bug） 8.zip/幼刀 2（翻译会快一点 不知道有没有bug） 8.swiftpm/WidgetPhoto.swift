// MARK: - 6. WidgetPhoto (4×2 照片组件：内存极速读写)
import SwiftUI

class PhotoWidgetManager: ObservableObject {
    static let shared = PhotoWidgetManager()
    
    private let photoIdKey = "App_Widget_4x2_ImageID"
    private let addedKey = "App_Widget_4x2_IsAdded"
    private let rowKey = "App_Widget_4x2_RowPosition"
    
    @Published var widgetImageData: Data? {
        didSet {
            Task.detached(priority: .utility) { [data = widgetImageData] in
                let oldId = UserDefaults.standard.string(forKey: "App_Widget_4x2_ImageID")
                LocalImageStore.shared.delete(id: oldId)
                if let newId = LocalImageStore.shared.save(data: data) {
                    UserDefaults.standard.set(newId, forKey: "App_Widget_4x2_ImageID")
                }
            }
        }
    }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        let rawRow = UserDefaults.standard.integer(forKey: rowKey)
        self.widgetRow = (rawRow % 2 == 0) ? min(max(0, rawRow), 4) : 0
    }
}

struct PhotoWidget4x2View: View {
    var imageData: Data?
    var isEditing: Bool = false
    var onDelete: (() -> Void)? = nil
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Group {
                if let data = imageData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage).resizable().scaledToFill()
                } else {
                    ZStack {
                        LinearGradient(
                            colors: [Color.purple.opacity(0.35), Color.blue.opacity(0.25)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                        VStack(spacing: 8) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 32))
                                .foregroundColor(.white.opacity(0.9))
                            Text(translator.translate("卡片"))
                                .font(.subheadline)
                                .fontWeight(appearance.systemFontWeight)
                                .foregroundColor(.white)
                            Text(translator.translate("点击选取相册照片"))
                                .font(.caption2)
                                .fontWeight(appearance.systemFontWeight)
                                .foregroundColor(.white.opacity(0.8))
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 160)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
            )
            .contentShape(Rectangle())
            
            if isEditing, let onDelete = onDelete {
                Button(action: onDelete) { WidgetDeleteBadge() }
                    .padding(8)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        .frame(height: 160)
    }
}

extension WidgetRegistry {
    func registerPhotoWidget() {
        registerWidget(
            id: "photo",
            title: "widget_photo_title",
            subtitle: "sub_photo",
            badge: "4×2",
            manager: PhotoWidgetManager.shared,
            desktopView: {
                PhotoWidget4x2View(imageData: PhotoWidgetManager.shared.widgetImageData, isEditing: false)
            },
            previewView: {
                PhotoWidget4x2View(imageData: PhotoWidgetManager.shared.widgetImageData, isEditing: false)
                    .frame(height: 160).padding(.horizontal, 16)
            },
            editSheetView: { _ in EmptyView() }
        )
    }
}
