// MARK: - AppAndWidgetRegistry.swift (系统级通用插件插座 - 严格控制在 100 行以内)
import SwiftUI

// ==========================================
// 1. 桌面软件 (App) 协议与注册插座
// ==========================================
struct AppDefinition: Identifiable {
    let id: String
    let defaultName: String
    let defaultIcon: String
    let defaultColorName: String
    let viewBuilder: (Binding<Bool>) -> AnyView
}

@MainActor
final class AppRegistry: ObservableObject {
    static let shared = AppRegistry()
    @Published var registeredApps: [String: AppDefinition] = [:]
    
    func register<V: View>(id: String, name: String, icon: String, colorName: String, view: @escaping (Binding<Bool>) -> V) {
        registeredApps[id] = AppDefinition(
            id: id,
            defaultName: name,
            defaultIcon: icon,
            defaultColorName: colorName,
            viewBuilder: { AnyView(view($0)) }
        )
    }
    
    var allApps: [AppDefinition] {
        Array(registeredApps.values).sorted(by: { $0.id < $1.id })
    }
}

// ==========================================
// 2. 桌面小组件 (Widget) 协议与注册插座
// ==========================================
protocol DesktopWidgetManager: AnyObject {
    var sizeRows: Int { get }
    var sizeCols: Int { get }
    var isAddedToDesktop: Bool { get set }
    var widgetRow: Int { get set }
    var widgetCol: Int { get set }
    var widgetPage: Int { get set }
}

extension DesktopWidgetManager {
    var widgetPage: Int {
        get {
            let key = "App_Widget_Page_\(String(describing: type(of: self)))"
            return UserDefaults.standard.integer(forKey: key)
        }
        set {
            let key = "App_Widget_Page_\(String(describing: type(of: self)))"
            UserDefaults.standard.set(newValue, forKey: key)
        }
    }
}

extension InsPostWidgetManager: DesktopWidgetManager {
    var sizeRows: Int { 4 }
    var sizeCols: Int { 4 }
    var widgetCol: Int { get { 0 } set {} }
}
extension KoreanMessageWidgetManager: DesktopWidgetManager {
    var sizeRows: Int { 2 }
    var sizeCols: Int { 4 }
    var widgetCol: Int { get { 0 } set {} }
}
extension PhotoWidgetManager: DesktopWidgetManager {
    var sizeRows: Int { 2 }
    var sizeCols: Int { 4 }
    var widgetCol: Int { get { 0 } set {} }
}
extension ChatBubbleWidgetManager: DesktopWidgetManager {
    var sizeRows: Int { 2 }
    var sizeCols: Int { 2 }
}

struct WidgetDefinition: Identifiable {
    let id: String
    let titleKey: String
    let subtitleKey: String
    let sizeBadgeKey: String
    let sizeRows: Int
    let sizeCols: Int
    
    let desktopView: () -> AnyView
    let previewView: () -> AnyView
    let editSheetView: (Binding<Bool>) -> AnyView
    let manager: any DesktopWidgetManager
}

@MainActor
final class WidgetRegistry: ObservableObject {
    static let shared = WidgetRegistry()
    @Published var registeredWidgets: [WidgetDefinition] = []
    
    init() {
        registerInsWidget()
        registerKoreanWidget()
        registerBubbleWidget()
        registerPhotoWidget()
    }
    
    func registerWidget<D: View, P: View, E: View>(
        id: String,
        title: String,
        subtitle: String,
        badge: String,
        manager: any DesktopWidgetManager,
        desktopView: @escaping () -> D,
        previewView: @escaping () -> P,
        editSheetView: @escaping (Binding<Bool>) -> E
    ) {
        guard !registeredWidgets.contains(where: { $0.id == id }) else { return }
        
        let def = WidgetDefinition(
            id: id,
            titleKey: title,
            subtitleKey: subtitle,
            sizeBadgeKey: badge,
            sizeRows: manager.sizeRows,
            sizeCols: manager.sizeCols,
            desktopView: { AnyView(desktopView()) },
            previewView: { AnyView(previewView()) },
            editSheetView: { AnyView(editSheetView($0)) },
            manager: manager
        )
        registeredWidgets.append(def)
    }
    
    var activeManagers: [DesktopWidgetManager] {
        registeredWidgets.map { $0.manager }
    }
}
