// MARK: - 2. CoreManagers (数据模型与全局系统管理器 · 丝滑零延迟版)
import SwiftUI
import UIKit
import Combine

// MARK: - App 实体模型
struct AppItem: Identifiable, Codable, Equatable {
    let id: String
    var title: String
    var icon: String
    var colorName: String
    
    var color: Color {
        switch colorName {
        case "gray": return .gray
        case "green": return .green
        case "blue": return .blue
        case "orange": return .orange
        case "red": return .red
        case "purple": return .purple
        default: return .gray
        }
    }
    
    func localizedTitle(customManager: CustomIconManager, lang: LanguageManager) -> String {
        if let custom = customManager.getTitle(for: self.id), !custom.isEmpty {
            // 特判：用户输入的自定义名称为「微信」或「WeChat」，直接对齐系统级词条
            if custom == "微信" || custom.caseInsensitiveCompare("WeChat") == .orderedSame {
                return lang.tr("app_wechat")
            }
            if custom == "设置" || custom.caseInsensitiveCompare("Settings") == .orderedSame {
                return lang.tr("app_settings")
            }
            if custom.caseInsensitiveCompare("iScreen") == .orderedSame {
                return lang.tr("app_iscreen")
            }
            return AutoTranslationManager.shared.translate(custom, to: lang.currentLanguage)
        }
        if self.id == "settings" { return lang.tr("app_settings") }
        if self.id == "wechat" { return lang.tr("app_wechat") }
        if self.id == "iscreen" { return lang.tr("app_iscreen") }
        return AutoTranslationManager.shared.translate(self.title, to: lang.currentLanguage)
    }
}

// MARK: - 拖拽换位坐标定位枚举
enum AppLocation: Equatable {
    case grid(Int)
    case dock(Int)
    
    var isDock: Bool {
        if case .dock = self { return true }
        return false
    }
}

// MARK: - 设置应用全局路由枚举
enum SettingsRoute: Hashable {
    case language
    case appearance
    case wallpaper
    case apiConfig
    case modelSelection
}

class SettingsNavManager: ObservableObject {
    static let shared = SettingsNavManager()
    @Published var path: [SettingsRoute] = []
}

// MARK: - 自定义 App 图标与名称管理器 (内存缓存直读)
class CustomIconManager: ObservableObject {
    static let shared = CustomIconManager()
    
    private let titleStorageKey = "App_Custom_App_Titles_Map"
    
    @Published var customIcons: [String: Data] = [:]
    @Published var customTitles: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customTitles) {
                    UserDefaults.standard.set(data, forKey: self.titleStorageKey)
                }
            }
        }
    }
    
    init() {
        if let data = UserDefaults.standard.data(forKey: titleStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customTitles = decoded
            for title in self.customTitles.values {
                AutoTranslationManager.shared.prewarm(text: title)
            }
        }
    }
    
    func setIcon(for appId: String, imageData: Data) {
        customIcons[appId] = imageData
    }
    
    func removeIcon(for appId: String) {
        customIcons.removeValue(forKey: appId)
    }
    
    func getIcon(for appId: String) -> Data? {
        return customIcons[appId]
    }
    
    func setTitle(for appId: String, title: String) {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            customTitles.removeValue(forKey: appId)
        } else {
            customTitles[appId] = trimmed
            Task {
                for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                    _ = await AutoTranslationManager.shared.translateAsync(trimmed, to: lang)
                }
            }
        }
    }
    
    func removeTitle(for appId: String) {
        customTitles.removeValue(forKey: appId)
    }
    
    func getTitle(for appId: String) -> String? {
        return customTitles[appId]
    }
}

// MARK: - 外观与系统设置管理
class SystemAppearance: ObservableObject {
    static let shared = SystemAppearance()
    
    @Published var isAuto: Bool = true { didSet { UserDefaults.standard.set(isAuto, forKey: "App_isAutoTheme") } }
    @Published var isDark: Bool = true { didSet { UserDefaults.standard.set(isDark, forKey: "App_isDarkTheme") } }
    @Published var hideHomeIndicator: Bool = false { didSet { UserDefaults.standard.set(hideHomeIndicator, forKey: "App_hideHomeIndicator") } }
    @Published var hideStatusBar: Bool = false { didSet { UserDefaults.standard.set(hideStatusBar, forKey: "App_hideStatusBar") } }
    @Published var systemFontWeightName: String = "regular" { didSet { UserDefaults.standard.set(systemFontWeightName, forKey: "App_systemFontWeightName") } }
    @Published var preferWidgetFontPriority: Bool = true { didSet { UserDefaults.standard.set(preferWidgetFontPriority, forKey: "App_preferWidgetFontPriority") } }
    
    var systemFontWeight: Font.Weight { Font.Weight.from(name: systemFontWeightName) }
    
    init() {
        if let autoVal = UserDefaults.standard.object(forKey: "App_isAutoTheme") as? Bool { self.isAuto = autoVal }
        if let darkVal = UserDefaults.standard.object(forKey: "App_isDarkTheme") as? Bool { self.isDark = darkVal }
        if let indicatorVal = UserDefaults.standard.object(forKey: "App_hideHomeIndicator") as? Bool { self.hideHomeIndicator = indicatorVal }
        if let statusVal = UserDefaults.standard.object(forKey: "App_hideStatusBar") as? Bool { self.hideStatusBar = statusVal }
        if let fontVal = UserDefaults.standard.string(forKey: "App_systemFontWeightName") { self.systemFontWeightName = fontVal }
        if let widgetPriorityVal = UserDefaults.standard.object(forKey: "App_preferWidgetFontPriority") as? Bool { self.preferWidgetFontPriority = widgetPriorityVal }
    }
    
    var colorScheme: ColorScheme? {
        if isAuto { return nil }
        return isDark ? .dark : .light
    }
}

extension View {
    @ViewBuilder
    func applyCustomAppearance(_ appearance: SystemAppearance) -> some View {
        if !appearance.isAuto {
            self.environment(\.colorScheme, appearance.isDark ? .dark : .light)
        } else {
            self
        }
    }
}

// MARK: - 壁纸管理 (内存即时生效 + 后台异步写盘)
@MainActor
class WallpaperManager: ObservableObject {
    static let shared = WallpaperManager()
    
    private let lockImageIdKey = "App_LockWallpaper_ImageID"
    private let homeImageIdKey = "App_HomeWallpaper_ImageID"
    
    @Published var lockScreenData: Data? {
        didSet {
            updateTones()
            Task.detached(priority: .utility) { [data = lockScreenData] in
                let oldId = UserDefaults.standard.string(forKey: "App_LockWallpaper_ImageID")
                LocalImageStore.shared.delete(id: oldId)
                if let newId = LocalImageStore.shared.save(data: data) {
                    UserDefaults.standard.set(newId, forKey: "App_LockWallpaper_ImageID")
                }
            }
        }
    }
    
    @Published var homeScreenData: Data? {
        didSet {
            updateTones()
            Task.detached(priority: .utility) { [data = homeScreenData] in
                let oldId = UserDefaults.standard.string(forKey: "App_HomeWallpaper_ImageID")
                LocalImageStore.shared.delete(id: oldId)
                if let newId = LocalImageStore.shared.save(data: data) {
                    UserDefaults.standard.set(newId, forKey: "App_HomeWallpaper_ImageID")
                }
            }
        }
    }
    
    @Published var isLockLight: Bool = false
    @Published var isHomeLight: Bool = false
    @Published var homeTextColor: Color = .white
    @Published var lockTextColor: Color = .white
    
    init() {
        if let lockId = UserDefaults.standard.string(forKey: lockImageIdKey) {
            self.lockScreenData = LocalImageStore.shared.load(id: lockId)
        }
        if let homeId = UserDefaults.standard.string(forKey: homeImageIdKey) {
            self.homeScreenData = LocalImageStore.shared.load(id: homeId)
        }
        updateTones()
    }
    
    func updateTones() {
        if let data = lockScreenData, let img = UIImage(data: data) {
            let analysis = img.analyzeWallpaperTone()
            self.isLockLight = analysis.isLight
            self.lockTextColor = analysis.textColor
        } else {
            self.isLockLight = false
            self.lockTextColor = .white
        }
        if let data = homeScreenData, let img = UIImage(data: data) {
            let analysis = img.analyzeWallpaperTone()
            self.isHomeLight = analysis.isLight
            self.homeTextColor = analysis.textColor
        } else {
            self.isHomeLight = false
            self.homeTextColor = .white
        }
    }
}
