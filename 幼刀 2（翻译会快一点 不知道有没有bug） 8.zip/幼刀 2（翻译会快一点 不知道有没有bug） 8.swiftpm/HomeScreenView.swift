// MARK: - 9. HomeScreenView (桌面排版与交互系统 · 极简轻量版)
import SwiftUI
import PhotosUI

// MARK: - 桌面单格子组件
struct GridSlotView: View {
    let slotIndex: Int
    let item: AppItem?
    let isEditing: Bool
    let isBeingDragged: Bool
    let textColor: Color
    let customTitle: String?
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        ZStack(alignment: .top) {
            if let item = item {
                let displayTitle = item.localizedTitle(customManager: iconManager, lang: lang)
                if isEditing {
                    AppIcon(icon: item.icon, color: item.color, title: displayTitle, textColor: textColor, customImageData: customImageData) {}
                        .modifier(JiggleModifier(isEditing: isEditing, slotIndex: slotIndex))
                        .opacity(isBeingDragged ? 0.0 : 1.0)
                        .transition(.identity)
                        .highPriorityGesture(
                            DragGesture(minimumDistance: 3, coordinateSpace: .global)
                                .onChanged { val in
                                    if !isBeingDragged { onDragStart(item, val.location) }
                                    else { onDragChange(val.location) }
                                }
                                .onEnded { val in onDragEnd(val.location) }
                        )
                } else {
                    AppIcon(icon: item.icon, color: item.color, title: displayTitle, textColor: textColor, customImageData: customImageData) { onLaunch() }
                        .transition(.identity)
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                                if !isEditing {
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                    onEnterEdit()
                                }
                            }
                        )
                }
            } else {
                Color.clear.transition(.identity)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 70)
        .transition(.identity)
    }
}

// MARK: - Dock 栏图标组件
struct DockItemView: View {
    let dockIndex: Int
    let item: AppItem
    let isEditing: Bool
    let isBeingDragged: Bool
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    var body: some View {
        ZStack {
            if isEditing {
                AppIcon(icon: item.icon, color: item.color, customImageData: customImageData) {}
                    .modifier(JiggleModifier(isEditing: isEditing, slotIndex: dockIndex + 100))
                    .opacity(isBeingDragged ? 0.0 : 1.0)
                    .transition(.identity)
                    .highPriorityGesture(
                        DragGesture(minimumDistance: 3, coordinateSpace: .global)
                            .onChanged { val in
                                if !isBeingDragged { onDragStart(item, val.location) }
                                else { onDragChange(val.location) }
                            }
                            .onEnded { val in onDragEnd(val.location) }
                    )
            } else {
                AppIcon(icon: item.icon, color: item.color, customImageData: customImageData) { onLaunch() }
                    .transition(.identity)
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !isEditing {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                onEnterEdit()
                            }
                        }
                    )
            }
        }
        .transition(.identity)
    }
}

// MARK: - 独立软件拖拽浮层（一直在手里）
struct ActiveDragOverlay: View {
    @ObservedObject var coordinator: DragCoordinator
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    let rootOrigin: CGPoint
    let screenH: CGFloat
    let contentColor: Color
    
    var body: some View {
        Group {
            if let dragged = coordinator.activeDraggingItem {
                let localPoint = CGPoint(
                    x: coordinator.activeGlobalLocation.x - rootOrigin.x,
                    y: coordinator.activeGlobalLocation.y - rootOrigin.y
                )
                let isNearDock = localPoint.y >= (screenH - 169)
                let shouldHideTitle = isNearDock || (coordinator.activeDragSource?.isDock == true && localPoint.y >= (screenH - 169))
                let displayTitle = dragged.localizedTitle(customManager: iconManager, lang: lang)
                
                AppIcon(
                    icon: dragged.icon,
                    color: dragged.color,
                    title: displayTitle,
                    textColor: contentColor.opacity(shouldHideTitle ? 0.0 : 1.0),
                    customImageData: iconManager.getIcon(for: dragged.id)
                ) {}
                    .frame(width: 60, height: 60)
                    .position(localPoint)
                    .allowsHitTesting(false)
                    .zIndex(99999)
            }
        }
    }
}

// 💡 独立小组件拖拽浮层：确保无论怎么翻页，小组件一直在手里！
enum DraggingWidgetType: Equatable {
    case ins, korean, photo, bubble
}

// MARK: - 桌面主视图
struct HomeScreenView: View {
    @Binding var isUnlocked: Bool
    
    @StateObject private var viewModel = HomeScreenViewModel()
    @StateObject private var dragCoordinator = DragCoordinator()
    
    @ObservedObject var insWidgetManager = InsPostWidgetManager.shared
    @ObservedObject var photoWidgetManager = PhotoWidgetManager.shared
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    @ObservedObject var koreanWidgetManager = KoreanMessageWidgetManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    @State private var activeAppId: String? = nil
    @State private var isSwiping = false
    @State private var currentPage = 0
    @State private var showAddWidgetSheet = false
    
    @State private var selectedWidgetPhotoItem: PhotosPickerItem? = nil
    @State private var selectedKoreanPhotoItem: PhotosPickerItem? = nil
    @State private var selectedInsPostPhotoItem: PhotosPickerItem? = nil
    
    // 全局持有小组件拖拽状态（让它始终在指尖）
    @State private var activeDraggingWidget: DraggingWidgetType? = nil
    @State private var widgetGlobalLocation: CGPoint = .zero
    @State private var widgetDragStartLocation: CGPoint = .zero
    
    // 原生边缘翻页定时器
    @State private var edgePagingTimer: DispatchWorkItem? = nil
    @State private var lastEdgePagingTime: Date = .distantPast
    
    @State private var lastEditTriggerTime: Date = .distantPast
    
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    private let columns: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: 18), count: 4)
    private let twoColumns: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: 18), count: 2)
    
    var contentColor: Color { wallpaperManager.homeTextColor }
    
    // 💡 完整保留进入编辑动画
    private func enterEditMode() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        lastEditTriggerTime = Date()
        withAnimation(.easeInOut(duration: 0.22)) { viewModel.isEditing = true }
    }
    
    var body: some View {
        GeometryReader { screenGeo in
            let screenW = screenGeo.size.width
            let screenH = screenGeo.size.height
            let rootOrigin = screenGeo.frame(in: .global).origin
            
            ZStack {
                VStack(spacing: 0) {
                    if viewModel.isEditing {
                        editHeaderView.transition(.opacity)
                    } else if !appearance.hideStatusBar {
                        statusBarView.transition(.opacity)
                    }
                    
                    gridContainerView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH)
                    Spacer(minLength: 6)
                    indicatorView
                    dockBarView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH)
                }
                .animation(.easeInOut(duration: 0.25), value: appearance.hideHomeIndicator)
                .animation(.easeInOut(duration: 0.25), value: appearance.hideStatusBar)
                .contentShape(Rectangle())
                // 💡 完整保留退出编辑动画
                .onTapGesture {
                    guard Date().timeIntervalSince(lastEditTriggerTime) > 0.5 else { return }
                    if viewModel.isEditing {
                        withAnimation(.easeInOut(duration: 0.22)) { viewModel.isEditing = false }
                        viewModel.saveApps()
                    }
                }
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                        if !viewModel.isEditing { enterEditMode() }
                    }
                )
                .overlay(
                    ActiveDragOverlay(
                        coordinator: dragCoordinator,
                        rootOrigin: rootOrigin,
                        screenH: screenH,
                        contentColor: contentColor
                    )
                )
                // 💡 全局小组件拖拽浮层：在屏幕最顶层吸附在手指下，翻页绝不丢！
                .overlay(
                    activeWidgetDragFloatingView(rootOrigin: rootOrigin, screenW: screenW)
                )
                .background(NativeImage(data: wallpaperManager.homeScreenData).ignoresSafeArea())
                .overlay(
                    Group {
                        if !appearance.hideHomeIndicator {
                            homeIndicatorBar.transition(.opacity)
                        }
                    },
                    alignment: .bottom
                )
                .ignoresSafeArea(.all, edges: .bottom)
                .gesture(lockDragGesture)
            }
        }
        .fontWeight(appearance.systemFontWeight)
        .overlay {
            ZStack {
                if let activeId = activeAppId, let appDef = AppRegistry.shared.registeredApps[activeId] {
                    appDef.viewBuilder(Binding(
                        get: { activeAppId == activeId },
                        set: { if !$0 { activeAppId = nil } }
                    ))
                    .background(Color(UIColor.systemBackground).ignoresSafeArea())
                    .transition(.asymmetric(insertion: .opacity, removal: .move(edge: .trailing)))
                    .zIndex(999)
                }
            }
            .ignoresSafeArea()
        }
        .onAppear {
            if AppRegistry.shared.registeredApps.isEmpty {
                AppRegistry.shared.register(id: "wechat", name: "微信", icon: "message.fill", colorName: "green") { show in
                    AIWeChatView(show: show)
                }
                AppRegistry.shared.register(id: "settings", name: "设置", icon: "gearshape.fill", colorName: "gray") { show in
                    SettingsView(show: show)
                }
                AppRegistry.shared.register(id: "iscreen", name: "iScreen", icon: "square.grid.2x2.fill", colorName: "purple") { show in
                    IScreenView(show: show)
                }
            }
            
            if WidgetRegistry.shared.registeredWidgets.isEmpty {
                WidgetRegistry.shared.registerInsWidget()
                WidgetRegistry.shared.registerKoreanWidget()
                WidgetRegistry.shared.registerBubbleWidget()
                WidgetRegistry.shared.registerPhotoWidget()
            }
            
            while viewModel.apps.count < 24 { viewModel.apps.append(nil) }
            viewModel.resolveWidgetRowCollisions()
            viewModel.evictAppsUnderWidgets()
            viewModel.deduplicateApps()
            viewModel.saveApps()
        }
        .sheet(isPresented: $showAddWidgetSheet) {
            AddWidgetSheetView(isPresented: $showAddWidgetSheet, viewModel: viewModel)
        }
        .task(id: selectedWidgetPhotoItem) {
            if let data = try? await selectedWidgetPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { photoWidgetManager.widgetImageData = data }
            }
        }
        .task(id: selectedKoreanPhotoItem) {
            if let data = try? await selectedKoreanPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { koreanWidgetManager.widgetImageData = data }
            }
        }
        .task(id: selectedInsPostPhotoItem) {
            if let data = try? await selectedInsPostPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { insWidgetManager.postImageData = data }
            }
        }
    }
    
    // MARK: - 实时边缘悬停翻页调度器（手不放开，到边缘 0.35s 自动翻页，带顺滑滑动动画）
    private func handleEdgeHoverPaging(globalX: CGFloat, rootOrigin: CGPoint, screenW: CGFloat) {
        let localX = globalX - rootOrigin.x
        let edgeThreshold: CGFloat = 50.0
        let isRightEdge = localX >= (screenW - edgeThreshold)
        let isLeftEdge = localX <= edgeThreshold
        
        guard isRightEdge || isLeftEdge else {
            edgePagingTimer?.cancel()
            edgePagingTimer = nil
            return
        }
        
        guard edgePagingTimer == nil else { return }
        guard Date().timeIntervalSince(lastEdgePagingTime) > 0.55 else { return }
        
        let work = DispatchWorkItem {
            guard Date().timeIntervalSince(lastEdgePagingTime) > 0.55 else { return }
            if isRightEdge {
                let nextP = currentPage + 1
                if nextP < viewModel.totalPages() || nextP <= 8 {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    // 💡 恢复丝滑横滑动画
                    withAnimation(.easeInOut(duration: 0.32)) {
                        currentPage += 1
                    }
                    lastEdgePagingTime = Date()
                }
            } else if isLeftEdge && currentPage > 0 {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                // 💡 恢复丝滑横滑动画
                withAnimation(.easeInOut(duration: 0.32)) {
                    currentPage -= 1
                }
                lastEdgePagingTime = Date()
            }
            edgePagingTimer = nil
        }
        
        edgePagingTimer = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: work)
    }
    
    private func cancelEdgePaging() {
        edgePagingTimer?.cancel()
        edgePagingTimer = nil
    }
    
    private var editHeaderView: some View {
        HStack {
            Button(action: {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                showAddWidgetSheet = true
            }) {
                HStack(spacing: 4) {
                    Image(systemName: "plus").font(.system(size: 11, weight: appearance.systemFontWeight))
                    Text(lang.tr("edit")).font(.system(size: 13, weight: appearance.systemFontWeight))
                }
                .foregroundColor(contentColor)
                .padding(.horizontal, 12).padding(.vertical, 4)
                .background(.ultraThinMaterial).clipShape(Capsule())
            }
            Spacer()
            Button(action: {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                withAnimation(.easeInOut(duration: 0.22)) { viewModel.isEditing = false }
                viewModel.saveApps()
            }) {
                Text(lang.tr("done"))
                    .font(.system(size: 13, weight: appearance.systemFontWeight))
                    .foregroundColor(contentColor)
                    .padding(.horizontal, 14).padding(.vertical, 4)
                    .background(.ultraThinMaterial).clipShape(Capsule())
            }
        }
        .padding(.horizontal, 20).padding(.top, -15).padding(.bottom, 0)
        .applyCustomAppearance(appearance)
    }
    
    private var statusBarView: some View {
        HStack {
            Text(lang.tr("carrier_name")).font(.caption).fontWeight(appearance.systemFontWeight)
            Spacer()
            Image(systemName: "wifi")
            Image(systemName: "battery.100")
        }
        .foregroundColor(contentColor).padding(.horizontal, 20).padding(.top, -15).padding(.bottom, 0)
    }
    
    private func gridContainerView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat) -> some View {
        TabView(selection: $currentPage) {
            ForEach(0..<viewModel.totalPages(), id: \.self) { pageIndex in
                let guaranteedSlots: [(index: Int, item: AppItem?)] = {
                    let start = pageIndex * 24
                    let end = start + 24
                    var result: [(index: Int, item: AppItem?)] = []
                    for i in start..<end {
                        let item = i < viewModel.apps.count ? viewModel.apps[i] : nil
                        result.append((index: i, item: item))
                    }
                    return result
                }()
                
                VStack(spacing: 20) {
                    desktopPageStructuredLayout(pageIndex: pageIndex, guaranteedSlots: guaranteedSlots, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH)
                }
                .padding(.horizontal, 24).padding(.top, 0).padding(.bottom, 2).tag(pageIndex)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        // 💡 恢复指示器和翻页感知动画
        .onChange(of: currentPage) { _, _ in
            withAnimation(.easeInOut(duration: 0.2)) { isSwiping = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                withAnimation(.easeInOut(duration: 0.2)) { isSwiping = false }
            }
        }
    }
    
    @ViewBuilder
    private func desktopPageStructuredLayout(pageIndex: Int, guaranteedSlots: [(index: Int, item: AppItem?)], rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat) -> some View {
        let halfWidth = max(0, (screenW - 48 - 18) / 2.0)
        let isInsOnThisPage = insWidgetManager.isAddedToDesktop && insWidgetManager.widgetPage == pageIndex
        
        if isInsOnThisPage && insWidgetManager.widgetRow == 0 {
            desktopInsWidgetView(rootOrigin: rootOrigin, screenW: screenW)
            renderSingleSlot(pageIndex: pageIndex, slotRow: 4, guaranteedSlots: guaranteedSlots, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, halfWidth: halfWidth)
        } else if isInsOnThisPage && insWidgetManager.widgetRow == 2 {
            renderSingleSlot(pageIndex: pageIndex, slotRow: 0, guaranteedSlots: guaranteedSlots, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, halfWidth: halfWidth)
            desktopInsWidgetView(rootOrigin: rootOrigin, screenW: screenW)
        } else if isInsOnThisPage {
            desktopInsWidgetView(rootOrigin: rootOrigin, screenW: screenW)
            renderSingleSlot(pageIndex: pageIndex, slotRow: 4, guaranteedSlots: guaranteedSlots, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, halfWidth: halfWidth)
        } else {
            ForEach([0, 2, 4], id: \.self) { slotRow in
                renderSingleSlot(pageIndex: pageIndex, slotRow: slotRow, guaranteedSlots: guaranteedSlots, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, halfWidth: halfWidth)
            }
        }
    }
    
    @ViewBuilder
    private func renderSingleSlot(pageIndex: Int, slotRow: Int, guaranteedSlots: [(index: Int, item: AppItem?)], rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat, halfWidth: CGFloat) -> some View {
        let isKoreanHere = koreanWidgetManager.isAddedToDesktop && koreanWidgetManager.widgetPage == pageIndex && koreanWidgetManager.widgetRow == slotRow
        let isPhotoHere = photoWidgetManager.isAddedToDesktop && photoWidgetManager.widgetPage == pageIndex && photoWidgetManager.widgetRow == slotRow
        let isBubbleHere = chatBubbleManager.isAddedToDesktop && chatBubbleManager.widgetPage == pageIndex && chatBubbleManager.widgetRow == slotRow
        
        if isKoreanHere {
            desktopKoreanWidgetView(rootOrigin: rootOrigin, screenW: screenW)
        } else if isPhotoHere {
            desktopPhotoWidgetView(rootOrigin: rootOrigin, screenW: screenW)
        } else if isBubbleHere {
            let isLeft = chatBubbleManager.widgetCol == 0
            HStack(spacing: 18) {
                if isLeft {
                    desktopBubbleWidgetView(rootOrigin: rootOrigin, screenW: screenW).frame(width: halfWidth)
                    let rightSlots = guaranteedSlots.filter { slot in
                        let slotInPage = slot.index % 24
                        let r = slotInPage / 4, c = slotInPage % 4
                        return (r == slotRow || r == slotRow + 1) && (c == 2 || c == 3)
                    }
                    LazyVGrid(columns: twoColumns, spacing: 20) {
                        ForEach(rightSlots, id: \.index) { slot in gridCell(slot: slot, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH) }
                    }
                    .frame(width: halfWidth)
                } else {
                    let leftSlots = guaranteedSlots.filter { slot in
                        let slotInPage = slot.index % 24
                        let r = slotInPage / 4, c = slotInPage % 4
                        return (r == slotRow || r == slotRow + 1) && (c == 0 || c == 1)
                    }
                    LazyVGrid(columns: twoColumns, spacing: 20) {
                        ForEach(leftSlots, id: \.index) { slot in gridCell(slot: slot, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH) }
                    }
                    .frame(width: halfWidth)
                    desktopBubbleWidgetView(rootOrigin: rootOrigin, screenW: screenW).frame(width: halfWidth)
                }
            }
            .frame(maxWidth: .infinity)
        } else {
            let slotSlots = guaranteedSlots.filter { slot in
                let slotInPage = slot.index % 24
                let r = slotInPage / 4
                return r == slotRow || r == slotRow + 1
            }
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(slotSlots, id: \.index) { slot in gridCell(slot: slot, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH) }
            }
        }
    }
    
    private func gridCell(slot: (index: Int, item: AppItem?), rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat) -> some View {
        GridSlotView(
            slotIndex: slot.index,
            item: slot.item,
            isEditing: viewModel.isEditing,
            isBeingDragged: dragCoordinator.activeDraggingItem?.id == slot.item?.id,
            textColor: contentColor,
            customTitle: slot.item != nil ? iconManager.getTitle(for: slot.item!.id) : nil,
            customImageData: slot.item != nil ? iconManager.getIcon(for: slot.item!.id) : nil,
            onLaunch: { if let item = slot.item { handleAppLaunch(item) } },
            onEnterEdit: { enterEditMode() },
            onDragStart: { item, globalPos in dragCoordinator.start(item: item, source: .grid(slot.index), location: globalPos) },
            onDragChange: { globalPos in 
                dragCoordinator.update(location: globalPos)
                handleEdgeHoverPaging(globalX: globalPos.x, rootOrigin: rootOrigin, screenW: screenW)
            },
            onDragEnd: { globalPos in 
                cancelEdgePaging()
                finishDragInstantly(globalPos: globalPos, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH) 
            }
        )
    }
    
    // MARK: - 页面内原位组件（拖拽时变虚，实物在手里）
    private func desktopInsWidgetView(rootOrigin: CGPoint, screenW: CGFloat) -> some View {
        let isBeingHeld = activeDraggingWidget == .ins
        return ZStack {
            InsPostWidget4x4View(
                avatarImageData: insWidgetManager.avatarImageData,
                postImageData: insWidgetManager.postImageData,
                avatarSize: insWidgetManager.avatarSize,
                hasBorder: insWidgetManager.hasBorder,
                borderWidth: insWidgetManager.borderWidth,
                borderColor: insWidgetManager.borderColor,
                headerCancelText: insWidgetManager.headerCancelText,
                headerCancelSize: insWidgetManager.headerCancelSize,
                headerCancelWeight: insWidgetManager.headerCancelWeight,
                headerCancelColor: insWidgetManager.headerCancelColor,
                headerTitle: insWidgetManager.headerTitle,
                headerTitleSize: insWidgetManager.headerTitleSize,
                headerTitleWeight: insWidgetManager.headerTitleWeight,
                headerTitleColor: insWidgetManager.headerTitleColor,
                headerSendText: insWidgetManager.headerSendText,
                headerSendSize: insWidgetManager.headerSendSize,
                headerSendWeight: insWidgetManager.headerSendWeight,
                headerSendColor: insWidgetManager.headerSendColor,
                sendIconSize: insWidgetManager.sendIconSize,
                sendIconColor: insWidgetManager.sendIconColor,
                sendIconOffsetX: insWidgetManager.sendIconOffsetX,
                sendIconOffsetY: insWidgetManager.sendIconOffsetY,
                authorName: insWidgetManager.authorName,
                authorNameSize: insWidgetManager.authorNameSize,
                authorNameWeight: insWidgetManager.authorNameWeight,
                authorNameColor: insWidgetManager.authorNameColor,
                authorSubText: insWidgetManager.authorSubText,
                authorSubTextSize: insWidgetManager.authorSubTextSize,
                authorSubTextWeight: insWidgetManager.authorSubTextWeight,
                authorSubTextColor: insWidgetManager.authorSubTextColor,
                contentText: insWidgetManager.contentText,
                contentTextSize: insWidgetManager.contentTextSize,
                contentTextWeight: insWidgetManager.contentTextWeight,
                contentTextColor: insWidgetManager.contentTextColor,
                isTransparent: insWidgetManager.isTransparentBackground,
                backgroundColor: insWidgetManager.backgroundColor,
                isEditing: viewModel.isEditing,
                onDelete: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.22)) {
                        insWidgetManager.isAddedToDesktop = false
                        viewModel.evictAppsUnderWidgets()
                    }
                    viewModel.saveApps()
                },
                onDeletePostImage: { withAnimation { insWidgetManager.postImageData = nil } },
                onSelectPostImage: { if !viewModel.isEditing { activeAppId = "iscreen" } } 
            )
            .modifier(JiggleModifier(isEditing: viewModel.isEditing, slotIndex: 666))
            .opacity(isBeingHeld ? 0.0 : 1.0)
        }
        .frame(maxWidth: .infinity).frame(height: 340)
        .conditionalDragGesture(isEditing: viewModel.isEditing) { val in
            if activeDraggingWidget == nil {
                activeDraggingWidget = .ins
                widgetDragStartLocation = val.location
            }
            widgetGlobalLocation = val.location
            handleEdgeHoverPaging(globalX: val.location.x, rootOrigin: rootOrigin, screenW: screenW)
        } onEnded: { val in
            cancelEdgePaging()
            finishDragWidgetGlobal(type: .ins, translation: CGSize(width: val.location.x - widgetDragStartLocation.x, height: val.location.y - widgetDragStartLocation.y))
        }
    }
    
    private func desktopKoreanWidgetView(rootOrigin: CGPoint, screenW: CGFloat) -> some View {
        let isBeingHeld = activeDraggingWidget == .korean
        return ZStack {
            KoreanMessageWidget4x2View(
                imageData: koreanWidgetManager.widgetImageData,
                isTransparent: koreanWidgetManager.isTransparentBackground,
                backgroundColor: koreanWidgetManager.backgroundColor,
                boxStyle: koreanWidgetManager.boxStyle,
                boxBorderWidth: koreanWidgetManager.boxBorderWidth,
                boxBorderColor: koreanWidgetManager.boxBorderColor,
                headerTitle: koreanWidgetManager.headerTitle,
                headerColor: koreanWidgetManager.headerColor,
                headerSize: koreanWidgetManager.headerSize,
                headerWeight: koreanWidgetManager.headerWeight,
                profileName: koreanWidgetManager.profileName,
                nameColor: koreanWidgetManager.nameColor,
                nameSize: koreanWidgetManager.nameSize,
                nameWeight: koreanWidgetManager.nameWeight,
                avatarSize: koreanWidgetManager.avatarSize,
                firstBarLeftText: koreanWidgetManager.firstBarLeftText,
                firstBarLeftColor: koreanWidgetManager.leftColor,
                firstBarLeftSize: koreanWidgetManager.leftSize,
                firstBarLeftWeight: koreanWidgetManager.leftWeight,
                firstBarRightText: koreanWidgetManager.firstBarRightText,
                firstBarRightColor: koreanWidgetManager.rightColor,
                firstBarRightSize: koreanWidgetManager.rightSize,
                firstBarRightWeight: koreanWidgetManager.rightWeight,
                secondBarText: koreanWidgetManager.secondBarText,
                secondBarColor: koreanWidgetManager.secondColor,
                secondBarSize: koreanWidgetManager.secondSize,
                secondBarWeight: koreanWidgetManager.secondWeight,
                sealColor: koreanWidgetManager.sealColor,
                sealSize: koreanWidgetManager.sealSize,
                isEditing: viewModel.isEditing,
                onDelete: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.22)) {
                        koreanWidgetManager.isAddedToDesktop = false
                        viewModel.evictAppsUnderWidgets()
                    }
                    viewModel.saveApps()
                }
            )
            .modifier(JiggleModifier(isEditing: viewModel.isEditing, slotIndex: 777))
            .opacity(isBeingHeld ? 0.0 : 1.0)
        }
        .frame(maxWidth: .infinity).frame(height: 160)
        .conditionalDragGesture(isEditing: viewModel.isEditing) { val in
            if activeDraggingWidget == nil {
                activeDraggingWidget = .korean
                widgetDragStartLocation = val.location
            }
            widgetGlobalLocation = val.location
            handleEdgeHoverPaging(globalX: val.location.x, rootOrigin: rootOrigin, screenW: screenW)
        } onEnded: { val in
            cancelEdgePaging()
            finishDragWidgetGlobal(type: .korean, translation: CGSize(width: val.location.x - widgetDragStartLocation.x, height: val.location.y - widgetDragStartLocation.y))
        }
    }
    
    private func desktopPhotoWidgetView(rootOrigin: CGPoint, screenW: CGFloat) -> some View {
        let isBeingHeld = activeDraggingWidget == .photo
        return ZStack {
            if viewModel.isEditing {
                PhotoWidget4x2View(
                    imageData: photoWidgetManager.widgetImageData,
                    isEditing: true,
                    onDelete: {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        withAnimation(.easeInOut(duration: 0.22)) {
                            photoWidgetManager.isAddedToDesktop = false
                            viewModel.evictAppsUnderWidgets()
                        }
                        viewModel.saveApps()
                    }
                )
                .modifier(JiggleModifier(isEditing: true, slotIndex: 888))
                .opacity(isBeingHeld ? 0.0 : 1.0)
                .highPriorityGesture(
                    DragGesture(minimumDistance: 3, coordinateSpace: .global)
                        .onChanged { val in
                            if activeDraggingWidget == nil {
                                activeDraggingWidget = .photo
                                widgetDragStartLocation = val.location
                            }
                            widgetGlobalLocation = val.location
                            handleEdgeHoverPaging(globalX: val.location.x, rootOrigin: rootOrigin, screenW: screenW)
                        }
                        .onEnded { val in 
                            cancelEdgePaging()
                            finishDragWidgetGlobal(type: .photo, translation: CGSize(width: val.location.x - widgetDragStartLocation.x, height: val.location.y - widgetDragStartLocation.y))
                        }
                )
            } else {
                PhotosPicker(selection: $selectedWidgetPhotoItem, matching: .images, photoLibrary: .shared()) {
                    PhotoWidget4x2View(imageData: photoWidgetManager.widgetImageData, isEditing: false)
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity).frame(height: 160)
    }
    
    private func desktopBubbleWidgetView(rootOrigin: CGPoint, screenW: CGFloat) -> some View {
        let isBeingHeld = activeDraggingWidget == .bubble
        return ZStack {
            ChatBubbleWidget2x2View(
                imageData: chatBubbleManager.widgetImageData,
                firstBubbleText: chatBubbleManager.firstBubbleText,
                secondBubbleText: chatBubbleManager.secondBubbleText,
                isTransparent: chatBubbleManager.isTransparentBackground,
                bubbleColor: chatBubbleManager.bubbleColor,
                bubbleTextColor: chatBubbleManager.bubbleTextColor,
                dateTextColor: chatBubbleManager.dateTextColor,
                bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                isEditing: viewModel.isEditing,
                showDashedBorder: false,
                onDelete: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.22)) {
                        chatBubbleManager.isAddedToDesktop = false
                        viewModel.evictAppsUnderWidgets()
                    }
                    viewModel.saveApps()
                }
            )
            .modifier(JiggleModifier(isEditing: viewModel.isEditing, slotIndex: 999))
            .opacity(isBeingHeld ? 0.0 : 1.0)
        }
        .frame(maxWidth: .infinity).frame(height: 160)
        .conditionalDragGesture(isEditing: viewModel.isEditing) { val in
            if activeDraggingWidget == nil {
                activeDraggingWidget = .bubble
                widgetDragStartLocation = val.location
            }
            widgetGlobalLocation = val.location
            handleEdgeHoverPaging(globalX: val.location.x, rootOrigin: rootOrigin, screenW: screenW)
        } onEnded: { val in
            cancelEdgePaging()
            finishDragWidgetGlobal(type: .bubble, translation: CGSize(width: val.location.x - widgetDragStartLocation.x, height: val.location.y - widgetDragStartLocation.y))
        }
    }
    
    // MARK: - 💡 无论翻多少页，手里永远吸附的全局浮层组件
    @ViewBuilder
    private func activeWidgetDragFloatingView(rootOrigin: CGPoint, screenW: CGFloat) -> some View {
        if let widgetType = activeDraggingWidget {
            let localPoint = CGPoint(
                x: widgetGlobalLocation.x - rootOrigin.x,
                y: widgetGlobalLocation.y - rootOrigin.y
            )
            let halfW = max(0, (screenW - 48 - 18) / 2.0)
            
            Group {
                switch widgetType {
                case .ins:
                    InsPostWidget4x4View(
                        avatarImageData: insWidgetManager.avatarImageData,
                        postImageData: insWidgetManager.postImageData,
                        avatarSize: insWidgetManager.avatarSize,
                        hasBorder: insWidgetManager.hasBorder,
                        borderWidth: insWidgetManager.borderWidth,
                        borderColor: insWidgetManager.borderColor,
                        headerCancelText: insWidgetManager.headerCancelText,
                        headerCancelSize: insWidgetManager.headerCancelSize,
                        headerCancelWeight: insWidgetManager.headerCancelWeight,
                        headerCancelColor: insWidgetManager.headerCancelColor,
                        headerTitle: insWidgetManager.headerTitle,
                        headerTitleSize: insWidgetManager.headerTitleSize,
                        headerTitleWeight: insWidgetManager.headerTitleWeight,
                        headerTitleColor: insWidgetManager.headerTitleColor,
                        headerSendText: insWidgetManager.headerSendText,
                        headerSendSize: insWidgetManager.headerSendSize,
                        headerSendWeight: insWidgetManager.headerSendWeight,
                        headerSendColor: insWidgetManager.headerSendColor,
                        sendIconSize: insWidgetManager.sendIconSize,
                        sendIconColor: insWidgetManager.sendIconColor,
                        sendIconOffsetX: insWidgetManager.sendIconOffsetX,
                        sendIconOffsetY: insWidgetManager.sendIconOffsetY,
                        authorName: insWidgetManager.authorName,
                        authorNameSize: insWidgetManager.authorNameSize,
                        authorNameWeight: insWidgetManager.authorNameWeight,
                        authorNameColor: insWidgetManager.authorNameColor,
                        authorSubText: insWidgetManager.authorSubText,
                        authorSubTextSize: insWidgetManager.authorSubTextSize,
                        authorSubTextWeight: insWidgetManager.authorSubTextWeight,
                        authorSubTextColor: insWidgetManager.authorSubTextColor,
                        contentText: insWidgetManager.contentText,
                        contentTextSize: insWidgetManager.contentTextSize,
                        contentTextWeight: insWidgetManager.contentTextWeight,
                        contentTextColor: insWidgetManager.contentTextColor,
                        isTransparent: insWidgetManager.isTransparentBackground,
                        backgroundColor: insWidgetManager.backgroundColor,
                        isEditing: true,
                        onDelete: {},
                        onDeletePostImage: {},
                        onSelectPostImage: {}
                    )
                    .frame(width: screenW - 48, height: 340)
                    .shadow(color: Color.black.opacity(0.25), radius: 16, x: 0, y: 10)
                    .scaleEffect(1.03)
                    
                case .korean:
                    KoreanMessageWidget4x2View(
                        imageData: koreanWidgetManager.widgetImageData,
                        isTransparent: koreanWidgetManager.isTransparentBackground,
                        backgroundColor: koreanWidgetManager.backgroundColor,
                        boxStyle: koreanWidgetManager.boxStyle,
                        boxBorderWidth: koreanWidgetManager.boxBorderWidth,
                        boxBorderColor: koreanWidgetManager.boxBorderColor,
                        headerTitle: koreanWidgetManager.headerTitle,
                        headerColor: koreanWidgetManager.headerColor,
                        headerSize: koreanWidgetManager.headerSize,
                        headerWeight: koreanWidgetManager.headerWeight,
                        profileName: koreanWidgetManager.profileName,
                        nameColor: koreanWidgetManager.nameColor,
                        nameSize: koreanWidgetManager.nameSize,
                        nameWeight: koreanWidgetManager.nameWeight,
                        avatarSize: koreanWidgetManager.avatarSize,
                        firstBarLeftText: koreanWidgetManager.firstBarLeftText,
                        firstBarLeftColor: koreanWidgetManager.leftColor,
                        firstBarLeftSize: koreanWidgetManager.leftSize,
                        firstBarLeftWeight: koreanWidgetManager.leftWeight,
                        firstBarRightText: koreanWidgetManager.firstBarRightText,
                        firstBarRightColor: koreanWidgetManager.rightColor,
                        firstBarRightSize: koreanWidgetManager.rightSize,
                        firstBarRightWeight: koreanWidgetManager.rightWeight,
                        secondBarText: koreanWidgetManager.secondBarText,
                        secondBarColor: koreanWidgetManager.secondColor,
                        secondBarSize: koreanWidgetManager.secondSize,
                        secondBarWeight: koreanWidgetManager.secondWeight,
                        sealColor: koreanWidgetManager.sealColor,
                        sealSize: koreanWidgetManager.sealSize,
                        isEditing: true,
                        onDelete: {}
                    )
                    .frame(width: screenW - 48, height: 160)
                    .shadow(color: Color.black.opacity(0.25), radius: 16, x: 0, y: 10)
                    .scaleEffect(1.03)
                    
                case .photo:
                    PhotoWidget4x2View(imageData: photoWidgetManager.widgetImageData, isEditing: true, onDelete: {})
                        .frame(width: screenW - 48, height: 160)
                        .shadow(color: Color.black.opacity(0.25), radius: 16, x: 0, y: 10)
                        .scaleEffect(1.03)
                    
                case .bubble:
                    ChatBubbleWidget2x2View(
                        imageData: chatBubbleManager.widgetImageData,
                        firstBubbleText: chatBubbleManager.firstBubbleText,
                        secondBubbleText: chatBubbleManager.secondBubbleText,
                        isTransparent: chatBubbleManager.isTransparentBackground,
                        bubbleColor: chatBubbleManager.bubbleColor,
                        bubbleTextColor: chatBubbleManager.bubbleTextColor,
                        dateTextColor: chatBubbleManager.dateTextColor,
                        bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                        isEditing: true,
                        showDashedBorder: false,
                        onDelete: {}
                    )
                    .frame(width: halfW, height: 160)
                    .shadow(color: Color.black.opacity(0.25), radius: 16, x: 0, y: 10)
                    .scaleEffect(1.03)
                }
            }
            .position(localPoint)
            .allowsHitTesting(false)
            .zIndex(999999)
        }
    }
    
    // MARK: - 松手时，在当前翻到的这一页智能落位互换
    private func finishDragWidgetGlobal(type: DraggingWidgetType, translation: CGSize) {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        activeDraggingWidget = nil
        
        switch type {
        case .ins:
            let oldPage = insWidgetManager.widgetPage
            let oldRow = insWidgetManager.widgetRow
            let step = Int(round(translation.height / 180.0)) * 2
            let newRow = min(max(0, oldRow + step), 2)
            let newPage = currentPage
            
            viewModel.smartRelocateWidget(
                oldPage: oldPage, oldRow: oldRow, oldCol: 0,
                newPage: newPage, newRow: newRow, newCol: 0,
                sizeRows: 4, sizeCols: 4
            ) {
                insWidgetManager.widgetPage = newPage
                insWidgetManager.widgetRow = newRow
            }
            
        case .korean:
            let oldPage = koreanWidgetManager.widgetPage
            let oldRow = koreanWidgetManager.widgetRow
            let step = Int(round(translation.height / 180.0)) * 2
            let newRow = min(max(0, oldRow + step), 4)
            let newPage = currentPage
            
            viewModel.smartRelocateWidget(
                oldPage: oldPage, oldRow: oldRow, oldCol: 0,
                newPage: newPage, newRow: newRow, newCol: 0,
                sizeRows: 2, sizeCols: 4
            ) {
                koreanWidgetManager.widgetPage = newPage
                koreanWidgetManager.widgetRow = newRow
            }
            
        case .photo:
            let oldPage = photoWidgetManager.widgetPage
            let oldRow = photoWidgetManager.widgetRow
            let step = Int(round(translation.height / 180.0)) * 2
            let newRow = min(max(0, oldRow + step), 4)
            let newPage = currentPage
            
            viewModel.smartRelocateWidget(
                oldPage: oldPage, oldRow: oldRow, oldCol: 0,
                newPage: newPage, newRow: newRow, newCol: 0,
                sizeRows: 2, sizeCols: 4
            ) {
                photoWidgetManager.widgetPage = newPage
                photoWidgetManager.widgetRow = newRow
            }
            
        case .bubble:
            let oldPage = chatBubbleManager.widgetPage
            let oldRow = chatBubbleManager.widgetRow
            let oldCol = chatBubbleManager.widgetCol
            let step = Int(round(translation.height / 180.0)) * 2
            let newRow = min(max(0, oldRow + step), 4)
            var newCol = oldCol
            if translation.width > 50 { newCol = 1 }
            else if translation.width < -50 { newCol = 0 }
            let newPage = currentPage
            
            viewModel.smartRelocateWidget(
                oldPage: oldPage, oldRow: oldRow, oldCol: oldCol * 2,
                newPage: newPage, newRow: newRow, newCol: newCol * 2,
                sizeRows: 2, sizeCols: 2
            ) {
                chatBubbleManager.widgetPage = newPage
                chatBubbleManager.widgetRow = newRow
                chatBubbleManager.widgetCol = newCol
            }
        }
    }
    
    // MARK: - Dock 栏与拖拽
    private func dockBarView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat) -> some View {
        HStack(spacing: 28) {
            ForEach(Array(viewModel.dockApps.enumerated()), id: \.element.id) { index, item in
                DockItemView(
                    dockIndex: index,
                    item: item,
                    isEditing: viewModel.isEditing,
                    isBeingDragged: dragCoordinator.activeDraggingItem?.id == item.id,
                    customImageData: iconManager.getIcon(for: item.id),
                    onLaunch: { handleAppLaunch(item) },
                    onEnterEdit: { enterEditMode() },
                    onDragStart: { item, globalPos in dragCoordinator.start(item: item, source: .dock(index), location: globalPos) },
                    onDragChange: { globalPos in 
                        dragCoordinator.update(location: globalPos)
                        handleEdgeHoverPaging(globalX: globalPos.x, rootOrigin: rootOrigin, screenW: screenW)
                    },
                    onDragEnd: { globalPos in 
                        cancelEdgePaging()
                        finishDragInstantly(globalPos: globalPos, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH) 
                    }
                )
            }
        }
        .frame(maxWidth: .infinity).frame(height: 90)
        .background(RoundedRectangle(cornerRadius: 32, style: .continuous).fill(.ultraThinMaterial))
        .padding(.horizontal, 15)
        .padding(.bottom, appearance.hideHomeIndicator ? 12 : 24)
        .applyCustomAppearance(appearance)
    }
    
    private func finishDragInstantly(globalPos: CGPoint, rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat) {
        guard let source = dragCoordinator.activeDragSource else {
            dragCoordinator.reset()
            return
        }
        let local = CGPoint(x: globalPos.x - rootOrigin.x, y: globalPos.y - rootOrigin.y)
        let destination = calculateTarget(at: local, source: source, screenW: screenW, screenH: screenH)
        
        viewModel.moveItem(from: source, to: destination)
        dragCoordinator.reset()
    }
    
    private func calculateTarget(at location: CGPoint, source: AppLocation, screenW: CGFloat, screenH: CGFloat) -> AppLocation {
        let dockTriggerHeight: CGFloat = appearance.hideHomeIndicator ? 117 : 129
        
        if location.y >= (screenH - dockTriggerHeight) {
            let dockCount = viewModel.dockApps.count
            if case .dock = source {
                let totalW = CGFloat(dockCount) * 60.0 + CGFloat(max(0, dockCount - 1)) * 28.0
                let startX = (screenW - totalW) / 2.0
                let relativeX = location.x - startX
                let rawIdx = Int(round(relativeX / 88.0))
                let targetDock = min(max(0, rawIdx), max(0, dockCount - 1))
                return .dock(targetDock)
            } else {
                let dockW = max(screenW - 30, 1)
                let rawCol = Int((location.x - 15) / (dockW / 4.0))
                let targetDock = min(max(0, rawCol), min(dockCount, 3))
                return .dock(targetDock)
            }
        } else {
            let usableW = max(screenW - 48, 1)
            let colW = usableW / 4.0
            let rowH: CGFloat = 90.0
            let col = min(max(0, Int((location.x - 24) / colW)), 3)
            let targetRow = min(max(0, Int((location.y - 30) / rowH)), 5)
            let slotInPage = targetRow * 4 + col
            let targetGrid = currentPage * viewModel.pageSize + slotInPage
            return .grid(targetGrid)
        }
    }
    
    private var indicatorView: some View {
        ZStack {
            if isSwiping && viewModel.totalPages() > 1 {
                HStack(spacing: 8) {
                    ForEach(0..<viewModel.totalPages(), id: \.self) { idx in
                        Circle().fill(contentColor.opacity(currentPage == idx ? 1.0 : 0.3)).frame(width: 7, height: 7)
                    }
                }
            } else {
                HStack(spacing: 3) {
                    Image(systemName: "magnifyingglass").font(.system(size: 9.8, weight: appearance.systemFontWeight))
                    Text(lang.tr("search")).font(.system(size: 12, weight: appearance.systemFontWeight))
                }
                .foregroundColor(contentColor.opacity(0.8))
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(.ultraThinMaterial).clipShape(Capsule())
                .scaleEffect(0.92)
            }
        }
        .frame(height: 30).padding(.bottom, 22).applyCustomAppearance(appearance)
    }
    
    private var homeIndicatorBar: some View {
        Capsule().fill(contentColor.opacity(0.5)).frame(width: 130, height: 5).padding(.bottom, 8)
    }
    
    private var lockDragGesture: some Gesture {
        DragGesture(minimumDistance: 30)
            .onEnded { value in
                guard !viewModel.isEditing else { return }
                if value.translation.height > 80 && abs(value.translation.height) > abs(value.translation.width) * 1.6 {
                    withAnimation(.easeInOut(duration: 0.4)) { isUnlocked = false }
                }
            }
    }
    
    private func handleAppLaunch(_ item: AppItem) {
        if AppRegistry.shared.registeredApps.keys.contains(item.id) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.86)) {
                activeAppId = item.id
            }
        } else {
            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        }
    }
}

extension View {
    @ViewBuilder
    func conditionalDragGesture(isEditing: Bool, onChanged: @escaping (DragGesture.Value) -> Void, onEnded: @escaping (DragGesture.Value) -> Void) -> some View {
        if isEditing {
            self.highPriorityGesture(
                DragGesture(minimumDistance: 3, coordinateSpace: .global)
                    .onChanged(onChanged)
                    .onEnded(onEnded)
            )
        } else {
            self
        }
    }
}

// MARK: - 点击 ➕ 弹出的小组件选择与添加窗口
struct AddWidgetSheetView: View {
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: HomeScreenViewModel 
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared 
    
    @State private var selectedCategory: String = "全部"
    private let sizeCategories = ["全部", "4×4", "4×2", "2×2"]
    @State private var selectedIndex: Int = 0
    
    private var filteredWidgets: [WidgetDefinition] {
        if selectedCategory == "全部" { return registry.registeredWidgets }
        return registry.registeredWidgets.filter { isWidgetMatchingCategory(widget: $0, category: selectedCategory) }
    }
    
    private func isWidgetMatchingCategory(widget: WidgetDefinition, category: String) -> Bool {
        if category == "全部" { return true }
        
        let normalize: (String) -> String = { str in
            str.lowercased()
                .replacingOccurrences(of: "badge_", with: "")
                .replacingOccurrences(of: "×", with: "x")
                .replacingOccurrences(of: "*", with: "x")
                .trimmingCharacters(in: .whitespaces)
        }
        
        let target = normalize(category)
        let badge = normalize(widget.sizeBadgeKey)
        let translatedBadge = normalize(lang.tr(widget.sizeBadgeKey))
        
        if badge == target || translatedBadge == target || badge.contains(target) {
            return true
        }
        
        switch target {
        case "2x2":
            return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2":
            return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4":
            return widget.sizeCols == 4 && widget.sizeRows == 4
        default:
            return false
        }
    }
    
    private var activeWidget: WidgetDefinition? {
        guard selectedIndex >= 0 && selectedIndex < filteredWidgets.count else { return nil }
        return filteredWidgets[selectedIndex]
    }
    
    private var isCurrentAdded: Bool {
        activeWidget?.manager.isAddedToDesktop ?? false
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    ForEach(sizeCategories, id: \.self) { cat in
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(.easeInOut(duration: 0.2)) {
                                selectedCategory = cat
                                selectedIndex = 0
                            }
                        }) {
                            Text(cat == "全部" ? lang.tr("cat_all") : cat)
                                .font(.system(size: 13, weight: selectedCategory == cat ? .semibold : appearance.systemFontWeight))
                                .padding(.horizontal, 14).padding(.vertical, 6)
                                .background(selectedCategory == cat ? Color.blue : Color(UIColor.secondarySystemFill))
                                .foregroundColor(selectedCategory == cat ? .white : .primary)
                                .clipShape(Capsule())
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 8)
                
                TabView(selection: $selectedIndex) {
                    ForEach(Array(filteredWidgets.enumerated()), id: \.element.id) { index, item in
                        VStack(spacing: 0) {
                            Spacer(minLength: 8)
                            item.previewView()
                            Spacer(minLength: 12)
                            VStack(spacing: 5) {
                                HStack(spacing: 6) {
                                    Text(lang.tr(item.titleKey)).font(.system(size: 19, weight: appearance.systemFontWeight)).foregroundColor(.primary)
                                    Text(lang.tr(item.sizeBadgeKey)).font(.system(size: 11, weight: appearance.systemFontWeight))
                                        .padding(.horizontal, 6).padding(.vertical, 2).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule())
                                }
                                Text(lang.tr(item.subtitleKey)).font(.caption).fontWeight(appearance.systemFontWeight).foregroundColor(.secondary).multilineTextAlignment(.center)
                            }
                            .padding(.horizontal, 20)
                            Spacer(minLength: 12)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: filteredWidgets.count > 1 ? .automatic : .never))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    while viewModel.apps.count < 24 { viewModel.apps.append(nil) }
                    
                    if let def = activeWidget {
                        if def.manager.isAddedToDesktop {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = false
                                viewModel.resolveWidgetRowCollisions()
                                viewModel.evictAppsUnderWidgets()
                            }
                        } else {
                            let placement = viewModel.findAvailablePlacement(forRows: def.sizeRows)
                            def.manager.widgetPage = placement.page
                            def.manager.widgetRow = placement.row
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = true
                                viewModel.resolveWidgetRowCollisions()
                                viewModel.evictAppsUnderWidgets()
                            }
                        }
                    }
                    viewModel.saveApps()
                    isPresented = false
                }) {
                    HStack(spacing: 8) {
                        if isCurrentAdded {
                            Image(systemName: "checkmark.circle.fill").font(.system(size: 16, weight: appearance.systemFontWeight))
                            Text(lang.tr("already_added")).font(.system(size: 16, weight: appearance.systemFontWeight))
                        } else {
                            Image(systemName: "plus.circle.fill").font(.system(size: 16, weight: appearance.systemFontWeight))
                            Text(lang.tr("add_to_home")).font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 14)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .padding(.horizontal, 24).padding(.bottom, 28)
            }
            .fontWeight(appearance.systemFontWeight)
            .navigationTitle(lang.tr("add_widget_nav_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(lang.tr("close")) { isPresented = false }
                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .presentationDetents([.fraction(0.85), .large])
        }
    }
}
