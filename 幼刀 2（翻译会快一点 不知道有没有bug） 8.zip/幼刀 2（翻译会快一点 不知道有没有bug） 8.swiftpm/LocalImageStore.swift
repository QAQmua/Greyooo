// MARK: - LocalImageStore.swift (本地沙盒磁盘 + 高速内存缓存中心)
import UIKit

final class LocalImageStore {
    static let shared = LocalImageStore()
    
    private let fileManager = FileManager.default
    private let memCache = NSCache<NSString, NSData>()
    
    private lazy var folderURL: URL = {
        let paths = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)
        let dir = paths[0].appendingPathComponent("AppImages", isDirectory: true)
        if !fileManager.fileExists(atPath: dir.path) {
            try? fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }()
    
    // 存图：返回图片唯一 ID
    func save(data: Data?) -> String? {
        guard let data = data, !data.isEmpty else { return nil }
        let id = UUID().uuidString
        let fileURL = folderURL.appendingPathComponent(id)
        memCache.setObject(data as NSData, forKey: id as NSString)
        do {
            try data.write(to: fileURL)
            return id
        } catch {
            return nil
        }
    }
    
    // 取图：先查内存缓存，未命中再读沙盒
    func load(id: String?) -> Data? {
        guard let id = id, !id.isEmpty else { return nil }
        if let cached = memCache.object(forKey: id as NSString) {
            return cached as Data
        }
        let fileURL = folderURL.appendingPathComponent(id)
        if let data = try? Data(contentsOf: fileURL) {
            memCache.setObject(data as NSData, forKey: id as NSString)
            return data
        }
        return nil
    }
    
    // 删图：彻底释放磁盘与缓存空间
    func delete(id: String?) {
        guard let id = id, !id.isEmpty else { return }
        memCache.removeObject(forKey: id as NSString)
        let fileURL = folderURL.appendingPathComponent(id)
        try? fileManager.removeItem(at: fileURL)
    }
}
