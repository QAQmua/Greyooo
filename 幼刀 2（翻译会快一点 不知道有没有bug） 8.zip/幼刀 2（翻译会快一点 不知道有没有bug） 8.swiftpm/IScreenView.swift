// MARK: - iScreen 小组件应用 (IScreenView) - 纯插件化瘦身版 (严格消灭硬编码)
import SwiftUI
import PhotosUI

struct IScreenView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    // 💡 接入统一组件总线
    @ObservedObject var registry = WidgetRegistry.shared
    
    @State private var currentTab: Int = 0
    @State private var activeEditWidgetID: String? = nil
    
    // 尺寸分类筛选状态
    @State private var selectedCategoryFilter: String = "全部"
    private let categoryFilters = ["全部", "2×2", "4×2", "4×4"]
    
    // 图标更换状态管理
    @State private var selectedAppPhotoItem: PhotosPickerItem? = nil
    @State private var targetAppForCustomIcon: String? = nil
    
    // 自定义名称弹窗状态
    @State private var showRenameAlert: Bool = false
    @State private var editingAppIdForRename: String? = nil
    @State private var inputAppName: String = ""
    
    @State private var isSearching: Bool = false
    @FocusState private var isSearchFocused: Bool
    @State private var searchText: String = ""
    @State private var searchHistory: [String] = ["ins发布页", "寄语卡片", "对话框", "卡片", "极简翻页钟", "拍立得", "仪表盘电量"]
    
    private let allPresets = [
        (title: "ins发布页", category: "社交", icon: "paperplane.fill", color: Color.purple),
        (title: "寄语卡片", category: "便签", icon: "envelope.fill", color: Color.pink),
        (title: "对话框", category: "挂件", icon: "bubble.left.and.bubble.right.fill", color: Color.blue),
        (title: "卡片", category: "照片", icon: "photo.on.rectangle.angled", color: Color.blue),
        (title: "极简翻页钟", category: "时钟", icon: "clock.fill", color: Color.indigo),
        (title: "时光拍立得", category: "照片", icon: "photo.fill", color: Color.teal),
        (title: "每日便签条", category: "便签", icon: "note.text", color: Color.orange),
        (title: "仪表盘电量", category: "系统", icon: "bolt.batteryblock.fill", color: Color.green)
    ]
    
    @State private var isEditingProfile: Bool = false
    @State private var userName: String = "极客探索者"
    @State private var userBio: String = "记录生活，探索桌面灵感 ✨"
    @State private var userUID: String = "89757"
    
    var activeEditWidgetBinding: Binding<Bool> {
        Binding(
            get: { activeEditWidgetID != nil },
            set: { if !$0 { activeEditWidgetID = nil } }
        )
    }
    
    private var activeEditingItemBinding: Binding<WidgetDefinition?> {
        Binding(
            get: {
                guard let id = activeEditWidgetID else { return nil }
                return registry.registeredWidgets.first(where: { $0.id == id })
            },
            set: { activeEditWidgetID = $0?.id }
        )
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                VStack(spacing: 0) {
                    if (currentTab == 0 || currentTab == 1) || isSearching { searchBarHeaderView }
                    
                    if isSearching { searchHistoryAndResultView } else {
                        switch currentTab {
                        case 0: homeRecommendScrollView
                        case 1: iconStudioView
                        case 2: workshopContentView
                        case 3: moreAccountContentView
                        default: homeRecommendScrollView
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.bottom, isSearching ? 0 : 90)
                
                if !isSearching {
                    liquidGlassTabBar.transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .alert("自定义应用名称".tr, isPresented: $showRenameAlert) {
            TextField("输入应用名称".tr, text: $inputAppName)
            Button("保存".tr) {
                if let appId = editingAppIdForRename {
                    iconManager.setTitle(for: appId, title: inputAppName)
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
            Button("恢复默认名称".tr, role: .destructive) {
                if let appId = editingAppIdForRename { iconManager.removeTitle(for: appId) }
            }
            Button("取消".tr, role: .cancel) {}
        } message: { Text("修改后的名称将实时在桌面和系统各处生效。".tr) }
            .simultaneousGesture(
                DragGesture(minimumDistance: 15).onEnded { value in
                    if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }
                }
            )
        // 💡 彻底消灭硬编码：所有组件弹窗全部走插件的 editSheetView！这里永远只有一行代码！
            .sheet(item: activeEditingItemBinding) { widgetDef in
                widgetDef.editSheetView(activeEditWidgetBinding)
            }
            .task(id: selectedAppPhotoItem) {
                if let item = selectedAppPhotoItem, let appId = targetAppForCustomIcon {
                    if let data = try? await item.loadTransferable(type: Data.self) {
                        withAnimation(.easeInOut(duration: 0.25)) { iconManager.setIcon(for: appId, imageData: data) }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                    }
                    selectedAppPhotoItem = nil
                    targetAppForCustomIcon = nil
                }
            }
    }
    
    // MARK: - 搜索栏
    private var searchBarHeaderView: some View {
        HStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").font(.system(size: 15, weight: .medium)).foregroundColor(.secondary)
                TextField("搜索小组件、图标主题...".tr, text: $searchText).font(.system(size: 14, weight: appearance.systemFontWeight)).foregroundColor(.primary).focused($isSearchFocused)
                if !searchText.isEmpty {
                    Button(action: { searchText = "" }) { Image(systemName: "xmark.circle.fill").font(.system(size: 14)).foregroundColor(.secondary) }
                }
            }
            .frame(maxWidth: .infinity).frame(height: 38).padding(.horizontal, 12)
            .background(Color(UIColor.secondarySystemFill)).clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            
            if isSearching {
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.22)) { isSearchFocused = false; isSearching = false; searchText = "" }
                }) { Text("取消".tr).font(.system(size: 16, weight: appearance.systemFontWeight)).foregroundColor(.gray).padding(.leading, 12).fixedSize() }
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
        .animation(.easeInOut(duration: 0.22), value: isSearching)
        .onChange(of: isSearchFocused) { _, focused in
            if focused && !isSearching { withAnimation(.easeInOut(duration: 0.22)) { isSearching = true } }
        }
    }
    
    private var searchHistoryAndResultView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                if searchText.trimmingCharacters(in: .whitespaces).isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("搜索历史".tr).font(.system(size: 14, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Spacer()
                            if !searchHistory.isEmpty {
                                Button(action: { withAnimation { searchHistory.removeAll() } }) { Image(systemName: "trash").font(.caption).foregroundColor(.secondary) }
                            }
                        }
                        if searchHistory.isEmpty {
                            Text("暂无搜索历史".tr).font(.caption).foregroundColor(.secondary.opacity(0.6)).padding(.top, 4)
                        } else {
                            FlowLayout(spacing: 8) {
                                ForEach(searchHistory, id: \.self) { item in
                                    Button(action: { searchText = item }) {
                                        Text(item.tr).font(.system(size: 12, weight: appearance.systemFontWeight)).foregroundColor(.primary).padding(.horizontal, 12).padding(.vertical, 6).background(Color(UIColor.secondarySystemFill)).clipShape(Capsule())
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16).padding(.top, 8)
                } else {
                    let results = allPresets.filter { $0.title.localizedCaseInsensitiveContains(searchText) || $0.category.localizedCaseInsensitiveContains(searchText) }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("\("搜索结果".tr) (\(results.count))").font(.caption).foregroundColor(.secondary).padding(.horizontal, 16)
                        if results.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "magnifyingglass").font(.system(size: 32)).foregroundColor(.secondary.opacity(0.4)).padding(.top, 40)
                                Text("\("未找到与".tr)“\(searchText)”\("相关的内容".tr)").font(.subheadline).foregroundColor(.secondary)
                            }.frame(maxWidth: .infinity)
                        } else {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 14)], spacing: 14) {
                                ForEach(results, id: \.title) { item in presetWidgetCard(title: item.title, category: item.category, icon: item.icon, color: item.color) }
                            }.padding(.horizontal, 16)
                        }
                    }
                }
            }
            .padding(.top, 8).padding(.bottom, 20)
        }
    }
    
    // MARK: - 页面 1：首页推荐
    private var homeRecommendScrollView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("热门推荐".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).padding(.horizontal, 16).padding(.top, 8)
                    HStack(spacing: 8) {
                        ForEach(categoryFilters, id: \.self) { filter in
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { selectedCategoryFilter = filter }
                            }) {
                                Text(filter == "全部" ? "全部".tr : filter)
                                    .font(.system(size: 12, weight: selectedCategoryFilter == filter ? .semibold : appearance.systemFontWeight))
                                    .padding(.horizontal, 14).padding(.vertical, 6)
                                    .background(selectedCategoryFilter == filter ? Color.blue : Color(UIColor.secondarySystemFill))
                                    .foregroundColor(selectedCategoryFilter == filter ? .white : .secondary).clipShape(Capsule())
                            }
                        }
                        Spacer()
                    }.padding(.horizontal, 16)
                }
                
                ForEach(registry.registeredWidgets) { widget in
                    if isWidgetMatchingFilter(widget: widget, filter: selectedCategoryFilter) {
                        VStack(alignment: .leading, spacing: 14) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(lang.tr(widget.titleKey)).font(.system(size: 17, weight: appearance.systemFontWeight))
                                    Text(lang.tr(widget.subtitleKey)).font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                
                                if widget.id != "photo" {
                                    Button(action: {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        activeEditWidgetID = widget.id
                                    }) {
                                        HStack(spacing: 4) {
                                            Image(systemName: "slider.horizontal.3").font(.system(size: 11, weight: .semibold))
                                            Text("定制".tr).font(.system(size: 12, weight: appearance.systemFontWeight))
                                        }
                                        .padding(.horizontal, 10).padding(.vertical, 4).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule())
                                    }
                                }
                                statusBadge(isAdded: widget.manager.isAddedToDesktop)
                            }
                            
                            Button(action: {
                                if widget.id != "photo" {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    activeEditWidgetID = widget.id
                                }
                            }) {
                                HStack {
                                    if widget.sizeCols < 4 { Spacer() }
                                    widget.previewView()
                                    if widget.sizeCols < 4 { Spacer() }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22)
                        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                        .padding(.horizontal, 16)
                        .transition(.asymmetric(insertion: .opacity.combined(with: .scale(scale: 0.98)), removal: .opacity))
                    }
                }
            }
            .animation(.spring(response: 0.3, dampingFraction: 0.86), value: selectedCategoryFilter)
            .padding(.bottom, 20)
        }
    }
    
    // MARK: - 智能尺寸匹配函数
    private func isWidgetMatchingFilter(widget: WidgetDefinition, filter: String) -> Bool {
        if filter == "全部" { return true }
        let normalize: (String) -> String = { str in
            str.lowercased()
                .replacingOccurrences(of: "×", with: "x")
                .replacingOccurrences(of: "*", with: "x")
                .trimmingCharacters(in: .whitespaces)
        }
        let target = normalize(filter)
        let badge = normalize(widget.sizeBadgeKey)
        if target == badge { return true }
        
        switch target {
        case "2x2":
            return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2":
            return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4":
            return widget.sizeCols == 4 && widget.sizeRows == 4
        default:
            return false
        }
    }
    
    private func statusBadge(isAdded: Bool) -> some View {
        Text(isAdded ? "已在桌面".tr : "未添加".tr)
            .font(.caption2.weight(.medium)).padding(.horizontal, 8).padding(.vertical, 3)
            .background(isAdded ? Color.blue.opacity(0.1) : Color(UIColor.tertiarySystemFill))
            .foregroundColor(isAdded ? .blue : .secondary).clipShape(Capsule())
    }
    
    private func colorMapping(_ name: String) -> Color {
        switch name {
        case "gray": return .gray; case "green": return .green; case "blue": return .blue
        case "orange": return .orange; case "red": return .red; case "purple": return .purple
        default: return .gray
        }
    }
    
    // MARK: - 页面 2：图标工坊
    private var iconStudioView: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "photo.stack.fill").font(.system(size: 22, weight: .bold)).foregroundColor(.blue)
                        Text("应用图标灵动工坊".tr).font(.system(size: 19, weight: appearance.systemFontWeight))
                        Spacer()
                        Text("iOS 26 驱动".tr).font(.system(size: 10, weight: .bold)).padding(.horizontal, 8).padding(.vertical, 4).background(Color.blue.opacity(0.15)).foregroundColor(.blue).clipShape(Capsule())
                    }
                    Text("点按右侧直接调取本地相册更换图片；点击名称或编辑图标即可自定义 App 软件名称。".tr).font(.caption).foregroundColor(.secondary).lineSpacing(3)
                }
                .padding(18).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22)
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                .padding(.horizontal, 16).padding(.top, 8)
                
                let apps = AppRegistry.shared.allApps
                let customizedAppCount = apps.filter { iconManager.getIcon(for: $0.id) != nil || iconManager.getTitle(for: $0.id) != nil }.count
                
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("桌面应用列表".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                        Spacer()
                        Text("\("已定制".tr) \(customizedAppCount) \("款".tr)").font(.caption).foregroundColor(.secondary)
                    }.padding(.horizontal, 16)
                    
                    VStack(spacing: 12) {
                        ForEach(apps, id: \.id) { app in
                            appIconCustomizerRow(
                                appId: app.id,
                                appName: app.defaultName,
                                defaultIcon: app.defaultIcon,
                                defaultColor: colorMapping(app.defaultColorName)
                            )
                        }
                    }.padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 20)
        }
    }
    
    // MARK: - 单个应用图标行
    private func appIconCustomizerRow(appId: String, appName: String, defaultIcon: String, defaultColor: Color) -> some View {
        let customData = iconManager.getIcon(for: appId)
        let customTitle = iconManager.getTitle(for: appId)
        let displayName = customTitle != nil ? customTitle! : appName.tr
        let isIconCustomized = customData != nil
        let isTitleCustomized = customTitle != nil
        let isCustomized = isIconCustomized || isTitleCustomized
        
        return HStack(spacing: 12) {
            Group {
                if let data = customData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage).resizable().scaledToFill().frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous)).overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.primary.opacity(0.08), lineWidth: 1))
                } else {
                    Image(systemName: defaultIcon).font(.system(size: 22)).foregroundColor(.white).frame(width: 48, height: 48).background(defaultColor).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
            
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Button(action: { editingAppIdForRename = appId; inputAppName = displayName; showRenameAlert = true }) {
                        HStack(spacing: 4) {
                            Text(translator.translate(displayName)).font(.system(size: 15, weight: appearance.systemFontWeight)).foregroundColor(.primary).lineLimit(1)
                            Image(systemName: "pencil").font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
                        }
                    }.buttonStyle(.plain)
                    if isCustomized { Text("已定制".tr).font(.system(size: 9, weight: .bold)).padding(.horizontal, 5).padding(.vertical, 2).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule()) }
                }
                Text(isCustomized ? "\("自定义".tr)\(appName.tr)\("图标".tr)" : "\("系统默认".tr)\(appName.tr)\("图标".tr)").font(.caption2).foregroundColor(.secondary).lineLimit(1)
            }.frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 6) {
                if isCustomized {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.easeInOut(duration: 0.2)) { iconManager.removeIcon(for: appId); iconManager.removeTitle(for: appId) }
                    }) { Image(systemName: "arrow.counterclockwise").font(.system(size: 11, weight: .bold)).foregroundColor(.secondary).frame(width: 28, height: 28).background(Color(UIColor.secondarySystemFill)).clipShape(Circle()) }
                }
                PhotosPicker(selection: $selectedAppPhotoItem, matching: .images, photoLibrary: .shared()) {
                    HStack(spacing: 4) {
                        Image(systemName: "photo.badge.plus").font(.system(size: 11, weight: .semibold))
                        Text(isIconCustomized ? "更换".tr : "选图".tr).font(.system(size: 12, weight: appearance.systemFontWeight))
                    }
                    .foregroundColor(.white).padding(.horizontal, 11).padding(.vertical, 6).background(Color.blue).clipShape(Capsule())
                }.simultaneousGesture(TapGesture().onEnded { targetAppForCustomIcon = appId })
            }
        }
        .frame(maxWidth: .infinity).padding(.horizontal, 14).padding(.vertical, 12).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
    }
    
    // MARK: - 页面 3：工坊
    private var workshopContentView: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                HStack(spacing: 14) {
                    Button(action: {}) {
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "plus.square.dashed").font(.system(size: 28)).foregroundColor(.blue)
                            VStack(alignment: .leading, spacing: 4) { Text("自制小组件".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).foregroundColor(.primary); Text("画布自由排版".tr).font(.caption2).foregroundColor(.secondary) }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
                    }
                    Button(action: {}) {
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "square.and.arrow.down.fill").font(.system(size: 28)).foregroundColor(.blue)
                            VStack(alignment: .leading, spacing: 4) { Text("导入组件".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).foregroundColor(.primary); Text("支持口令与代码".tr).font(.caption2).foregroundColor(.secondary) }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
                    }
                }.padding(.horizontal, 16).padding(.top, 14)
                
                VStack(alignment: .leading, spacing: 14) {
                    Text("\("我的自制库".tr) (\(registry.registeredWidgets.count))").font(.system(size: 14, weight: appearance.systemFontWeight)).padding(.horizontal, 16)
                    
                    ForEach(registry.registeredWidgets) { widget in
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(lang.tr(widget.titleKey)).font(.system(size: 17, weight: appearance.systemFontWeight))
                                    Text(lang.tr(widget.subtitleKey)).font(.caption2).foregroundColor(.secondary)
                                }
                                Spacer()
                                statusBadge(isAdded: widget.manager.isAddedToDesktop)
                            }
                            
                            HStack {
                                if widget.sizeCols < 4 { Spacer() }
                                widget.previewView()
                                if widget.sizeCols < 4 { Spacer() }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(20).padding(.horizontal, 16)
                    }
                }
            }.padding(.bottom, 20)
        }
    }
    
    // MARK: - 页面 4：更多 / 账号中心
    private var moreAccountContentView: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        Image(systemName: "person.crop.circle.fill").font(.size64).foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 4) {
                            if isEditingProfile { TextField("输入昵称".tr, text: $userName).font(.title3.weight(.bold)).textFieldStyle(.roundedBorder) } else { HStack { Text(translator.translate(userName)).font(.system(size: 19, weight: appearance.systemFontWeight)); Text("PRO").font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2).background(Color.blue).foregroundColor(.white).clipShape(Capsule()) } }
                            Text("UID: \(userUID)").font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("个人简介".tr).font(.caption).foregroundColor(.secondary)
                        if isEditingProfile { TextField("输入个性简介".tr, text: $userBio).font(.subheadline).textFieldStyle(.roundedBorder) } else { Text(translator.translate(userBio)).font(.system(size: 15, weight: appearance.systemFontWeight)).foregroundColor(.primary) }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    Divider()
                    Button(action: { withAnimation(.easeInOut(duration: 0.2)) { isEditingProfile.toggle() } }) { HStack { Image(systemName: isEditingProfile ? "checkmark.circle.fill" : "pencil.circle.fill"); Text(isEditingProfile ? "保存资料".tr : "编辑资料".tr).font(.system(size: 15, weight: appearance.systemFontWeight)) }.frame(maxWidth: .infinity).padding(.vertical, 10).background(isEditingProfile ? Color.green : Color(UIColor.secondarySystemFill)).foregroundColor(isEditingProfile ? .white : .primary).cornerRadius(12) }
                }.padding(20).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22).padding(.horizontal, 16).padding(.top, 14)
                
                VStack(spacing: 0) {
                    accountSettingRow(icon: "icloud.and.arrow.up.fill", title: "云端备份与恢复".tr, color: .blue)
                    Divider().padding(.leading, 52)
                    accountSettingRow(icon: "paintbrush.fill", title: "小组件刷新频率".tr, color: .orange)
                    Divider().padding(.leading, 52)
                    accountSettingRow(icon: "info.circle.fill", title: "关于 iScreen".tr, color: .blue)
                }.background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(20).padding(.horizontal, 16)
            }.padding(.bottom, 20)
        }
    }
    
    // MARK: - 液体玻璃底栏
    private var liquidGlassTabBar: some View {
        HStack(spacing: 0) {
            tabBarButton(index: 0, title: "首页".tr, icon: "sparkles.rectangle.stack.fill")
            tabBarButton(index: 1, title: "图标".tr, icon: "photo.stack.fill")
            tabBarButton(index: 2, title: "工坊".tr, icon: "hammer.fill")
            tabBarButton(index: 3, title: "更多".tr, icon: "person.crop.circle.fill")
        }
        .padding(.vertical, 8).padding(.horizontal, 16)
        .background(Capsule().fill(.ultraThinMaterial).overlay(Capsule().stroke(Color.primary.opacity(0.12), lineWidth: 0.6)).shadow(color: Color.black.opacity(0.08), radius: 15, y: 6))
        .frame(maxWidth: 400).padding(.horizontal, 20).padding(.bottom, 12)
    }
    
    private func tabBarButton(index: Int, title: String, icon: String) -> some View {
        Button(action: { withAnimation(.easeInOut(duration: 0.2)) { currentTab = index } }) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 20, weight: currentTab == index ? .bold : .medium))
                Text(title).font(.system(size: 11, weight: currentTab == index ? .semibold : appearance.systemFontWeight))
            }.frame(maxWidth: .infinity).foregroundColor(currentTab == index ? .blue : .secondary).padding(.vertical, 4)
        }
    }
    
    private func presetWidgetCard(title: String, category: String, icon: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack { Image(systemName: icon).font(.title2).foregroundColor(color); Spacer(); Text(category.tr).font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2).background(color.opacity(0.15)).foregroundColor(color).clipShape(Capsule()) }
            Text(title.tr).font(.system(size: 14, weight: appearance.systemFontWeight))
            Text("支持自定义规格".tr).font(.system(size: 10)).foregroundColor(.secondary)
        }.padding(14).frame(height: 105).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(16)
    }
    
    private func accountSettingRow(icon: String, title: String, color: Color) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 16, weight: .semibold)).foregroundColor(.white).frame(width: 30, height: 30).background(color).clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            Text(title).font(.system(size: 15, weight: appearance.systemFontWeight))
            Spacer()
            Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary.opacity(0.5))
        }.padding(.horizontal, 16).padding(.vertical, 14)
    }
}
